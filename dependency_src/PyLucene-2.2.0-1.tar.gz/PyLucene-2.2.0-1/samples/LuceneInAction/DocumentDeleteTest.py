
import os, sys, unittest

sys.path.append(os.path.dirname(os.path.abspath(sys.argv[0])))

import lia.indexing.DocumentDeleteTest
unittest.main(lia.indexing.DocumentDeleteTest)
